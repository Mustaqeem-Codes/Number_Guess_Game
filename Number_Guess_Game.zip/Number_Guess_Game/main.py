import os
import random
import pyjokes
import time
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

# Scoring rules
score_table = {
    1: 5, 2: 4.5, 3: 4, 4: 3.5, 5: 3.2, 6: 3, 7: 2.7, 8: 2.5,
    9: 2.3, 10: 2, 11: 1.8, 12: 1.6, 13: 1.4, 14: 1.2, 15: 1
}

USER_DIR = "users"
if not os.path.exists(USER_DIR):
    os.makedirs(USER_DIR)

# ✅ Helper: clear screen
def clear():
    os.system("cls" if os.name == "nt" else "clear")

def signup(username):
    filepath = os.path.join(USER_DIR, f"{username}.txt")
    if os.path.exists(filepath):
        print(Fore.YELLOW + "⚠ User already exists! Please login.")
        return False
    with open(filepath, "w") as f:
        pass
    print(Fore.GREEN + "✅ Signup successful! Please login now.")
    return True

def login(username):
    filepath = os.path.join(USER_DIR, f"{username}.txt")
    if not os.path.exists(filepath):
        print(Fore.RED + "⚠ User not found! Please sign up first.")
        return None
    print(Fore.CYAN + f"✅ Welcome back, {username}!")
    return filepath

def play_game(filepath):
    clear()
    number = random.randint(1, 50)
    print(Fore.MAGENTA + "🎮 New Game Started! Guess a number between 1-50")
    
    for attempt in range(1, 16):
        try:
            guess = int(input(Fore.CYAN + f"Attempt {attempt}: Enter your guess: "))
        except ValueError:
            print(Fore.RED + "❌ Invalid input! Enter a number only.")
            continue

        if guess < 1 or guess > 50:
            print(Fore.RED + "❌ Out of range! Guess between 1 and 50.")
            continue

        if guess == number:
            points = score_table[attempt]
            print(Fore.GREEN + f"🎉 Correct! You scored {points} points.")
            with open(filepath, "a") as f:
                f.write(str(points) + "\n")
            print(Fore.YELLOW + "😂 Here's a joke for you: \n" + Fore.WHITE + pyjokes.get_joke())
            time.sleep(2)
            return
        elif guess < number:
            print(Fore.BLUE + "Too low! Try higher.")
        else:
            print(Fore.MAGENTA + "Too high! Try lower.")
    print(Fore.RED + "❌ You lost! Try again!")

def view_scores(filepath):
    clear()
    with open(filepath, "r") as f:
        scores = [float(x.strip()) for x in f if x.strip()]
    if scores:
        print(Fore.CYAN + "📊 Your Scores (High → Low):")
        for i, score in enumerate(sorted(scores, reverse=True), 1):
            print(f"{i}. {score}")
    else:
        print(Fore.YELLOW + "No scores yet. Play a game first!")

def view_highest_scores(username):
    clear()
    all_scores = {}
    for file in os.listdir(USER_DIR):
        user = file.replace(".txt", "")
        with open(os.path.join(USER_DIR, file), "r") as f:
            scores = [float(x.strip()) for x in f if x.strip()]
        if scores:
            all_scores[user] = max(scores)

    if not all_scores:
        print(Fore.YELLOW + "No scores found yet.")
        return

    sorted_scores = sorted(all_scores.items(), key=lambda x: x[1], reverse=True)

    print(Fore.MAGENTA + "\n🏆 Leaderboard (Top 3):")
    for i, (user, score) in enumerate(sorted_scores[:3], 1):
        print(Fore.GREEN + f"{i}. {user} - {score}")

    # Show your rank
    for rank, (user, score) in enumerate(sorted_scores, 1):
        if user == username:
            print(Fore.CYAN + f"\n👉 Your rank: {rank} (Score: {score})")
            break

def main():
    while True:
        clear()
        print(Fore.YELLOW + "=== Number Guess Game ===")
        choice = input(Fore.CYAN + "\n1. Signup\n2. Login\n3. Exit\nChoose: ")
        if choice == "1":
            signup(input("Enter username: "))
            time.sleep(1.5)
        elif choice == "2":
            username = input("Enter username: ")
            filepath = login(username)
            time.sleep(1.5)
            if filepath:
                while True:
                    clear()
                    option = input(Fore.CYAN + 
                                   "\n1. Start Game\n2. View My Scores\n3. View Highest Scores\n4. Logout\nChoose: ")
                    if option == "1":
                        play_game(filepath)
                        input(Fore.YELLOW + "\nPress Enter to continue...")
                    elif option == "2":
                        view_scores(filepath)
                        input(Fore.YELLOW + "\nPress Enter to continue...")
                    elif option == "3":
                        view_highest_scores(username)
                        input(Fore.YELLOW + "\nPress Enter to continue...")
                    elif option == "4":
                        break
        elif choice == "3":
            print(Fore.GREEN + "👋 Goodbye!")
            break
        else:
            print(Fore.RED + "❌ Invalid choice!")
            time.sleep(1.5)

if __name__ == "__main__":
    main()
